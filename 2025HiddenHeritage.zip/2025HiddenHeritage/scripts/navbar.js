// Toggle dropdown menu on hamburger menu click
const hamburgerMenu = document.querySelector('.hamburger-menu');
const dropdownMenu = document.querySelector('.dropdown-menu');

hamburgerMenu.addEventListener('click', () => {
    dropdownMenu.classList.toggle('active');
});

// Close dropdown menu when clicking outside
document.addEventListener('click', (event) => {
    if (!hamburgerMenu.contains(event.target) && !dropdownMenu.contains(event.target)) {
        dropdownMenu.classList.remove('active');
    }
});