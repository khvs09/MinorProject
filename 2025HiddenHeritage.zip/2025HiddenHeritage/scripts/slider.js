const heroSlider = document.querySelector('.hero-slider');
const images = heroSlider.querySelectorAll('img');
let currentIndex = 0;

function showNextImage() {
    images[currentIndex].classList.remove('active');
    currentIndex = (currentIndex + 1) % images.length; // Cycles through 3 images
    images[currentIndex].classList.add('active');
}

// Automatically change images every 5 seconds
setInterval(showNextImage, 5000);

// Show the first image initially
images[currentIndex].classList.add('active');